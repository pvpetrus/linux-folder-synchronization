hejka naklejka
