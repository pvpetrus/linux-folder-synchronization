#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

typedef unsigned int uint;
typedef unsigned char ubyte;
typedef char byte;

byte copyFile(const char* zrodlo, const char* destynacja,uint rozmiar_bufora)
{
	
	int plik_wejsciowy=open(zrodlo, O_RDONLY ) ;
	if(plik_wejsciowy==-1)
	{
		printf("blad otwierania pliku wejsciowego");
		return -1;
	}
	int plik_wyjsciowy=open(destynacja, O_WRONLY | O_CREAT | O_TRUNC ,0700);
	if(plik_wyjsciowy==-1)
	{
		close(plik_wejsciowy);
		printf("blad otwierania pliku  wyjsciowego");
		return -1;
	}
	ubyte *bufor=malloc(rozmiar_bufora);
	while(1==1)
	{
	int czytaj_bity=read(plik_wejsciowy,bufor,rozmiar_bufora);
	write(plik_wyjsciowy,bufor,czytaj_bity);
	if(czytaj_bity<rozmiar_bufora)
		break;
	}
	free(bufor);
	close(plik_wejsciowy);
	close(plik_wyjsciowy);
}
int main(int arg,char **argv)
{
	uint rozmiar_bufora = strtol(argv[3],NULL,10);
	copyFile(argv[1],argv[2],rozmiar_bufora);
}
